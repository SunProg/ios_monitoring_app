//
//  TimeCalculator.swift
//  StudyApp
//
//  Created by cscoi049 on 2017. 2. 14..
//  Copyright © 2017년 INI. All rights reserved.
//

import Foundation

func timeCalculation(_counter:Int) -> (String) {
    
    let _seconds = _counter % 60
    let _minutes = (_counter % 3600) / 60
    let _hour = _counter / 3600
    
    if _hour > 0 {
        return String(format: "%d:%02d:%02d",_hour, _minutes, _seconds)
    }
    else {
        return String(format: "%02d:%02d", _minutes, _seconds)
    }
}



class TimeInfo {
    var startTime:NSDate
    var studyTime:TimeInterval
    
    init(_startTime: NSDate, _studyTime: TimeInterval) {
        self.startTime = _startTime
        self.studyTime = _studyTime
    }

    
}
