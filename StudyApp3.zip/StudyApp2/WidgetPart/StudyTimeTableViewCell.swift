//
//  StudyTimeTableViewCell.swift
//  StudyApp
//
//  Created by cscoi049 on 2017. 2. 14..
//  Copyright © 2017년 INI. All rights reserved.
//

import UIKit

class StudyTimeTableViewCell: UITableViewCell {

    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var studyTimeLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
