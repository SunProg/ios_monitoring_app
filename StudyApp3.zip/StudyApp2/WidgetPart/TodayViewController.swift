//
//  TodayViewController.swift
//  WidgetPart
//
//  Created by cscoi049 on 2017. 2. 13..
//  Copyright © 2017년 INI. All rights reserved.
//

import UIKit
import NotificationCenter


@IBDesignable


class TodayViewController: UIViewController, NCWidgetProviding {
    var Timers = Timer()
    var counter = 0
    var seconds = 0
    var minutes = 0
    var hour = 0
    var pauseNum = 0
    var playing = false
    var studyTimeArray = [TimeInfo]()
    var timeNow = NSDate()
    var studyTime: TimeInterval = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.extensionContext?.widgetLargestAvailableDisplayMode = NCWidgetDisplayMode.expanded
        
        
        TimeLabel.text = "00:00"
        progressView.setProgress(0, animated: true)
        progressView.transform = progressView.transform.scaledBy(x: 1, y: 2)
        userImage.layer.masksToBounds = false
        userImage.layer.cornerRadius = userImage.frame.height/2
        userImage.clipsToBounds = true
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func widgetPerformUpdate(completionHandler: (@escaping (NCUpdateResult) -> Void)) {
        // Perform any setup necessary in order to update the view.
        
        // If an error is encountered, use NCUpdateResult.Failed
        // If there's no update required, use NCUpdateResult.NoData
        // If there's an update, use NCUpdateResult.NewData
        
        completionHandler(NCUpdateResult.newData)
    }
    func updateCounter() {
        counter += 1
        TimeLabel.text = timeCalculation(_counter: counter)
        let progressValue = Float(counter) / 60
        progressView.setProgress(progressValue, animated: true)
        progressLabel.text = String(Int(progressValue*100)) + "%"
    }
    
    @IBOutlet weak var TimeLabel: UILabel!
    
    @IBOutlet weak var progressView: UIProgressView!
    
    @IBAction func startPause(_ sender: UIButton) {
        if playing == false {
            Timers = Timer.scheduledTimer(timeInterval: 1, target:self, selector: #selector(TodayViewController.updateCounter), userInfo: nil, repeats: true)
            playing = true
            sender.setImage(UIImage(named: "pauseIcon.png"), for: .normal)
            timeNow = NSDate()
        }
        else {
            Timers.invalidate()
            playing = false
            sender.setImage(UIImage(named: "playIcon.png"), for: .normal)
            studyTime = timeNow.timeIntervalSinceNow
            studyTimeArray.append(TimeInfo(_startTime: timeNow, _studyTime: studyTime))
            createNewLabel()
            
        }
        
    }
    
    func createNewLabel () {
        // CGRectMake has been deprecated - and should be let, not var
        let label = UILabel(frame: CGRect(x: 0, y: 0, width: 50, height: 20))
        
        // you will probably want to set the font (remember to use Dynamic Type!)
        label.font = UIFont.preferredFont(forTextStyle: .footnote)
        
        // and set the text color too - remember good contrast
        label.textColor = .black
        
        // may not be necessary (e.g., if the width & height match the superview)
        // if you do need to center, CGPointMake has been deprecated, so use this
        label.center = CGPoint(x: 180, y: 100 + 20 * pauseNum)
        
        // this changed in Swift 3 (much better, no?)
        label.textAlignment = .center
        label.text = timeCalculation(_counter: Int(studyTimeArray[pauseNum].studyTime) * -1)

        pauseNum += 1
        self.view.addSubview(label)
    }
    
    @IBOutlet weak var userImage: UIImageView!
    @IBOutlet weak var playPauseButton: UIButton!
    @IBOutlet weak var resetButton: UIButton!
    @IBOutlet weak var progressLabel: UILabel!
    
    
    @IBAction func resetButton(_ sender: UIButton) {
        Timers.invalidate()
        playing = false
        counter = 0
        seconds = 0
        minutes = 0
        hour = 0
        pauseNum = 0
        TimeLabel.text = "00:00"
        playPauseButton.setImage(UIImage(named: "playIcon"), for: .normal)
        progressView.setProgress(0, animated: true)
        progressLabel.text = "0%"
        studyTimeArray.removeAll()
    }
    
    
    func widgetActiveDisplayModeDidChange(_ activeDisplayMode: NCWidgetDisplayMode, withMaximumSize maxSize: CGSize){
        if (activeDisplayMode == NCWidgetDisplayMode.compact) {
            self.preferredContentSize = maxSize;
        }
        else {
            self.preferredContentSize = CGSize(width: 0, height: 1000);
        }
    }
}
