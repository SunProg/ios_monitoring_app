//
//  TodayViewController.swift
//  WidgetPart
//
//  Created by cscoi049 on 2017. 2. 13..
//  Copyright © 2017년 INI. All rights reserved.
//

import UIKit
import NotificationCenter


@IBDesignable
class TodayViewController: UIViewController, NCWidgetProviding {
    
    var Timers = Timer()
    var counter = 0
    var seconds = 0
    var minutes = 0
    var hour = 0
    var playing = false
    override func viewDidLoad() {
        super.viewDidLoad()
        self.extensionContext?.widgetLargestAvailableDisplayMode = NCWidgetDisplayMode.expanded
        
        TimeLabel.text = "00:00"
        progressView.setProgress(0, animated: true)
        //progressView.setProgress(0, animated: true)
        // Do any additional setup after loading the view from its nib.
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func widgetPerformUpdate(completionHandler: (@escaping (NCUpdateResult) -> Void)) {
        // Perform any setup necessary in order to update the view.
        
        // If an error is encountered, use NCUpdateResult.Failed
        // If there's no update required, use NCUpdateResult.NoData
        // If there's an update, use NCUpdateResult.NewData
        
        completionHandler(NCUpdateResult.newData)
    }
    func updateCounter() {
        counter += 1
        seconds += 1
        if seconds == 60 {
            minutes += 1
            seconds = 0
        }
        if minutes == 60 {
            hour += 1
        }
        if hour > 0 {
            TimeLabel.text = String(format: "%d:%02d:%02d",hour, minutes, seconds)
        }
        else {
            TimeLabel.text = String(format: "%02d:%02d", minutes, seconds)
        }
        progressView.setProgress(Float(counter) / 100, animated: true)
    }
    
    @IBOutlet weak var TimeLabel: UILabel!
    
    @IBOutlet weak var progressView: UIProgressView!
    
    @IBAction func startPause(_ sender: UIButton) {
        if playing == false {
            Timers = Timer.scheduledTimer(timeInterval: 1, target:self, selector: #selector(TodayViewController.updateCounter), userInfo: nil, repeats: true)
            playing = true
            sender.setImage(UIImage(named: "pauseIcon.png"), for: .normal)
        }
        else {
            Timers.invalidate()
            playing = false
            sender.setImage(UIImage(named: "playIcon.png"), for: .normal)
        }
        
    }
    
    @IBOutlet weak var playPauseButton: UIButton!
    @IBOutlet weak var resetButton: UIButton!
    @IBAction func resetButton(_ sender: UIButton) {
        Timers.invalidate()
        playing = false
        counter = 0
        seconds = 0
        minutes = 0
        hour = 0
        TimeLabel.text = "00:00"
        playPauseButton.setImage(UIImage(named: "playIcon"), for: .normal)
        progressView.setProgress(0, animated: true)
    }
    func widgetActiveDisplayModeDidChange(_ activeDisplayMode: NCWidgetDisplayMode, withMaximumSize maxSize: CGSize){
        if (activeDisplayMode == NCWidgetDisplayMode.compact) {
            self.preferredContentSize = maxSize;
        }
        else {
            self.preferredContentSize = CGSize(width: 0, height: 200);
        }
    }
}
